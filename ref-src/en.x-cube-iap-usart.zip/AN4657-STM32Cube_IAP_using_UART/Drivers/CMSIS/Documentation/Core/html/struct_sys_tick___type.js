var struct_sys_tick___type =
[
    [ "CALIB", "struct_sys_tick___type.html#a9c9eda0ea6f6a7c904d2d75a6963e238", null ],
    [ "CTRL", "struct_sys_tick___type.html#af2ad94ac83e5d40fc6e34884bc1bec5f", null ],
    [ "LOAD", "struct_sys_tick___type.html#ae7bc9d3eac1147f3bba8d73a8395644f", null ],
    [ "VAL", "struct_sys_tick___type.html#a0997ff20f11817f8246e8f0edac6f4e4", null ]
];